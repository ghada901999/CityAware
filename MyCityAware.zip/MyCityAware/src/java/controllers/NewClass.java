/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;

/**
 *
 * @author MOHAMMAD
 */
public class NewClass {
    private int var=3;
    
    public NewClass()
    {
        var += 7 ;
        
        System.out.println(var);
        
    }
    
}
