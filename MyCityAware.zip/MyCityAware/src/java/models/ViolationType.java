/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author MOHAMMAD
 */
public enum ViolationType {
    RED_LIGHT_CROSSING,
    STOP_SIGN_RUNNING,
    JAYWALKING,
    LITTERING
}
